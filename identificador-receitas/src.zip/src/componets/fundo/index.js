
import React from 'react';
import './fundo.css';

function Fundo(){
    return(
        <div className="fundo8">
        <div className="centro">
            
        </div>
        </div>
    )
}
export default Fundo;